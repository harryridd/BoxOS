
var delta=0;
var myBtn2=document.getElementById("myBtn2")
var myBtn2m=document.getElementById("myBtn2m")
var myBtn3=document.getElementById("myBtn3")
var myBtn4=document.getElementById("myBtn4")
var txt1=document.getElementById("txt1")
var txt2=document.getElementById("txt2")
var txt3=document.getElementById("txt3")
myBtn2.onclick=function(){

}
function rename1(idd,ddi){
var prom=prompt("Change the name of the app");

if(prom==null){

alert("Please enter a new name for the app");
}
else if(prom==""){

alert("Please enter a new name for the app");
}
else{
idd.innerHTML=prom
ddi.innerHTML=prom
}
}
function none(){
   document.getElementById("myBtn2").style.display="none"
   
   delta=1;
   }
   function none1(){
   document.getElementById("myBtn3").style.display="none"
   delta=2;
   }
   function none2(){
   document.getElementById("myBtn4").style.display="none"
   delta=3;
   }
   
   function back(){
   if(delta==0){
   alert("Trashcan is empty.")
   
   }
   else{
   if(delta==1){
   document.getElementById("myBtn2").style.display="block"
   alert("Last app deleted is recovered.");
   delta=0;
   }
   else if(delta==2){
   document.getElementById("myBtn3").style.display="block"
   alert("Last app deleted is recovered.");
   delta=0;
   }
   else if(delta==3){
   document.getElementById("myBtn4").style.display="block"
   alert("Last app deleted is recovered.");
   delta=0;
   }
   }
   
   }
var settin1=document.getElementById("settin1");
var settin2=document.getElementById("settin2");
var settin3=document.getElementById("settin3");
if (document.addEventListener) { // IE >= 9; other browsers
var x = document.getElementsByClassName("program");
var i;

    x[0].addEventListener('contextmenu', function(e) {
    //MAKE RIGHT CLICK MENU
  
   if(settin2.style.display=="block"){
    myBtn3.style.marginTop="0px"
    myBtn4.style.marginTop="0px"
    }
    else{
    settin1.style.display="block";
    setti1.style.display="block";
    myBtn3.style.marginTop="40px"; 
    settin1.style.marginTop="0px";
    setti1.style.marginTop="10px";
    
    myBtn2.appendChild(setti1)
    myBtn2.appendChild(settin1)
    myBtn2.onclick=function(){
    }
    
    }

    settin2.style.display="none";settin3.style.display="none";
    setti2.style.display="none";setti3.style.display="none";
    window.onclick = function(event) {
    if (event.target != settin1) {
   setti1.style.display = "none";
    settin1.style.display = "none";
    myBtn3.style.marginTop="0px"; 
    myBtn2.onclick=function(){
    modal2.style.display = "block";
    
    }
    }
    }
    e.preventDefault();
    }, false);
x[1].addEventListener('contextmenu', function(e) {
    //MAKE RIGHT CLICK MENU
  
   
    
    if(settin1.style.display=="block"){
    myBtn3.style.marginTop="0px"
    }
   else if(setti1.style.display=="block"){
    myBtn3.style.marginTop="0px"
    }
    else{
  
    settin2.style.display="block";
   settin2.style.marginTop="0px";
    setti2.style.display="block";
   
    myBtn4.style.marginTop="40px";
    setti2.style.marginTop="10px";

    myBtn3.appendChild(setti2)
    myBtn3.appendChild(settin2)
   
    myBtn3.onclick=function(){
    }
    
    }
    settin1.style.display="none";settin3.style.display="none";
    setti1.style.display="none";setti3.style.display="none";
    settin2.style.marginTop = "0px";

    window.onclick = function(event) {
    if (event.target != settin2) {
    settin2.style.display = "none";
    setti2.style.display = "none";
     myBtn4.style.marginTop="0px"; 
   myBtn3.onclick=function(){
   modal3.style.display = "block";
   
   }
    }
    }
    e.preventDefault();
    }, false);
x[2].addEventListener('contextmenu', function(e) {
    //MAKE RIGHT CLICK MENU
    if(settin1.style.display=="block"){
    myBtn3.style.marginTop="0px"
    settin1.style.display="none"
    }
else if(settin2.style.display=="block"){
 myBtn4.style.marginTop="0px"
 settin2.style.display="none"
 }
else if(setti1.style.display=="block"){
    myBtn3.style.marginTop="0px"
    setti1.style.display="none"
    }
 else if(setti2.style.display=="block"){
 myBtn4.style.marginTop="0px"
 setti2.style.display="none"
 }
 else{

    settin3.style.display="block";
    setti3.style.display="block";
settin2.style.display="none";settin1.style.display="none";
    setti2.style.display="none";setti1.style.display="none";
 
  myBtn4.appendChild(setti3)
  myBtn4.appendChild(settin3)
  myBtn4.onclick=function(){
  }
  
  }
  settin2.style.display="none";settin1.style.display="none";
  setti2.style.display="none";setti1.style.display="none";
  
  setti3.style.marginTop = "10px";
  settin3.style.marginTop = "0px";
    window.onclick = function(event) {
    if (event.target != settin3) {
    settin3.style.display = "none";
    setti3.style.display = "none";
   myBtn4.onclick=function(){
   modal4.style.display = "block";
   
   }
    }
    }
    e.preventDefault();
    }, false);

       }
    
    
function toggleFullScreen() {
    var doc = window.document;
    var docEl = doc.documentElement;
    
    var requestFullScreen = docEl.requestFullscreen || docEl.mozRequestFullScreen || docEl.webkitRequestFullScreen || docEl.msRequestFullscreen;
    var cancelFullScreen = doc.exitFullscreen || doc.mozCancelFullScreen || doc.webkitExitFullscreen || doc.msExitFullscreen;
    
    if(!doc.fullscreenElement && !doc.mozFullScreenElement && !doc.webkitFullscreenElement && !doc.msFullscreenElement) {
    requestFullScreen.call(docEl);
    document.getElementById("body").style.height="100%";
   
    document.getElementById("body").style.overflow="hidden";
    }
    else {
    cancelFullScreen.call(doc);
    document.getElementById("body").style.height="auto";
    }
    }
function res(){
document.getElementById("to").value="";
document.getElementById("subj").value=null;
document.getElementById("bod").value=null;

}
function fu(){
   var to= document.getElementById("to")
      var subj=document.getElementById("subj")
   var snd=document.getElementById("snd")
   var bod=document.getElementById("bod")
   snd.setAttribute("href","mailto:"+to.value+"@gmail.com?subject="+subj.value+"&body="+bod.value);
    
    }
    var modal4 = document.getElementById('myModal4');
    
    var btn4 = document.getElementById("myBtn4");
    
    var span4 = document.getElementById("close4");
    
    function maaam() {
    modal4.style.display = "block";
    }
    
    
    span4.onclick = function() {
    modal4.style.display = "none";
    }
    
    
    window.onclick = function(event) {
    if (event.target == modal4) {
    modal4.style.display = "none";
    }
    }
var numbb=0;
function woo(){
if(numbb==0){

document.getElementById("1.txt").style.width="70px";
document.getElementById("1.txt").style.height="70px";

document.getElementById("2.txt").style.width="70px";
document.getElementById("2.txt").style.height="70px";

document.getElementById("3.txt").style.width="70px";
document.getElementById("3.txt").style.height="70px";
numbb=1;
}
else{
document.getElementById("2.txt").style.width="100px";
document.getElementById("2.txt").style.height="100px";

document.getElementById("3.txt").style.width="100px";
document.getElementById("3.txt").style.height="100px";
document.getElementById("1.txt").style.width="100px";
document.getElementById("1.txt").style.height="100px";
numbb=0;
}
}
function myFun1(){

var x = document.getElementById("selec");
var xii = Number(prompt("Please type a number that the folder you want to remove from top is...0=First Folder"));
if(xii==""){

alert("Please enter a number");
}
else if (isNaN(xii) || typeof xii !== "number") {
  alert("That wasn't a number. Please enter a number.");
}  else {
  x.remove(xii);
}
}
function myFun() {
    var x = document.getElementById("selec");
    var option = document.createElement("option");
    var choo=prompt("Name your new folder...");
    option.text = choo;
    if(choo.length==0){
    alert("Please name your new folder");
    }
    else{
    x.add(option);
    }
}
function chng1(){
document.getElementById("chnggg").style.float="left";
document.getElementById("chnggg").style.marginRight="0px";

}
function chng2(){
document.getElementById("chnggg").style.float="right";
document.getElementById("chnggg").style.marginRight="20px";

}
var i=document.getElementById("i");
var a11=document.getElementById("a11");

function funn(){

i.addEventListener("keyup", function(event) {
    event.preventDefault();
    if (event.keyCode === 13) {
        
        window.open("https://"+i.value);
        
    }
});
}
 function clck(){
 window.open("https://"+i.value);
 
 }

var selec=document.getElementById("selec");
function sel(){
if(selec.value==1){
document.getElementById("1.txt").style.display="block";
document.getElementById("2.txt").style.display="none";
document.getElementById("3.txt").style.display="none";
}
else if(selec.value==2){
document.getElementById("1.txt").style.display="none";
document.getElementById("2.txt").style.display="none";
document.getElementById("3.txt").style.display="none";
}

else if(selec.value==3){
document.getElementById("1.txt").style.display="none";
document.getElementById("2.txt").style.display="block";
document.getElementById("3.txt").style.display="block";
}
else{
document.getElementById("1.txt").style.display="none";
document.getElementById("2.txt").style.display="none";
document.getElementById("3.txt").style.display="none";


}
}
function v(){
document.body.style.backgroundImage="url('Back2.jpg')";
}
function b(){
document.body.style.backgroundImage="url('Back1.jpg')";
}
function a(){
document.body.style.backgroundImage="url('Back3.jpg')";
}
function m(){
document.body.style.backgroundImage="url('Back4.jpg')";
}
function d(){
setInterval(fun,0)
function fun(){
var today = new Date();
    var h = today.getHours();
    var m = today.getMinutes();
    document.getElementById('clc').innerHTML =
    h + ":" + m  ;
    
   document.getElementById("dateee").innerHTML=today.getDate()+"/"+today.getMonth()+"/"+today.getFullYear();
    
    }
   
}


    var modal1 = document.getElementById('myModal1');
    

    var btn1 = document.getElementById("myBtn1");
    
    
    var span = document.getElementById("close1");
    
    
    btn1.onclick = function() {
    modal1.style.display = "block";
    }
    
    span.onclick = function() {
    modal1.style.display = "none";
    }
    
  
    window.onclick = function(event) {
    if (event.target == modal1) {
    modal1.style.display = "none";
    }
    }
    
  
    var modal2 = document.getElementById('myModal2');
    
    var btn1 = document.getElementById("myBtn2");
    
    var span = document.getElementById("close2");
    
    btn1.onclick = function() {
    modal2.style.display = "block";
    }
    
  
    span.onclick = function() {
    modal2.style.display = "none";
    }
    
    
    window.onclick = function(event) {
    if (event.target == modal2) {
    modal2.style.display = "none";
    }
    }
    var modal3 = document.getElementById('myModal3');
    
    var btn3 = document.getElementById("myBtn3");
    
    var span3 = document.getElementById("close3");
    
    btn3.onclick = function() {
    modal3.style.display = "block";
    }
    
    
    span3.onclick = function() {
    modal3.style.display = "none";
    }
    
    
    window.onclick = function(event) {
    if (event.target == modal3) {
    modal3.style.display = "none";
    }
    }
function wow(){

var ic=document.getElementById("ic");

document.getElementById("bar").style.backgroundColor=ic.value

}
function transp(alpha){

document.getElementById("bar").style.opacity=alpha;
}

